This project is the reproduction of the paper https://arxiv.org/pdf/1803.04173.pdf.   
the main model is from https://github.com/XenderLiu/MalConv-Pytorch   
I wrote the gradient_attack.py and did some other modifications to generate adversarial samples towards the model.
